<?php
/**
 * 
 * Template Name: HomePage
 * 
 */

get_header(); ?>





















<?php get_footer(); ?>