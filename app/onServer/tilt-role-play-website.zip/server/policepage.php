<?php
/**
 * 
 * Template Name: PolicePage
 * 
 */

get_header(); ?>





















<?php get_footer(); ?>