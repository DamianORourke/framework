<?php
/**
 * 
 * Template Name: UniversityPage
 * 
 */

get_header(); ?>





















<?php get_footer(); ?>